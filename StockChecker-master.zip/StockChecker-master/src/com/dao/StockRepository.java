package com.dao;

import com.models.StockQuote;
import com.services.CreateFile;
import com.utils.Extraction;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * <h1>Data Access Object</h1>
 * <p>This class is used for manipulating, storing and reading data from a file</p>
 *
 * @author Tomas Kaiser
 * @version 1.0
 * @since 04-11-2020
 * */

public class StockRepository {
    private List<String> lines = new ArrayList<>();
    private String line;
    private File file;

    private BufferedWriter bw;
    private BufferedReader br;
    private StockQuote stockQuote;

    public StockRepository() {
        CreateFile.createJSONFile("storage");
        file = new File("temp/storage.json");
    }

    /**
     * This method is used to save a stock quote to a file. It makes used of
     * readFileAndStoreInList & writeIntoFile method.
     *
     * @param stockQuote This is a stock quote to be saved.
     * @retun Nothing.
     * @exception Exception on input error.
     * */
    public void save(StockQuote stockQuote) throws Exception {
        readFileAndStoreInList();
        writeIntoFile(stockQuote);
    }

    /**
     * This method is used to update existing stock quote in a file. It makes used of readFileAndStoreInList
     * & writeIntoFile method.
     *
     * @param stockQuote This is a stock quote to be saved.
     * @retun Nothing.
     * @exception Exception on input/output error.
     * */
    public void update(StockQuote stockQuote) throws Exception {
        readFileAndStoreInList();

        // Removes the symbol along with price from list
        for (int i = 0; i < lines.size(); i++){
            if (lines.get(i).equalsIgnoreCase("\"Symbol\": " + stockQuote.getSymbol() + ",")){
                lines.remove(i + 8);
                lines.remove(i + 7);
                lines.remove(i + 6);
                lines.remove(i + 5);
                lines.remove(i + 4);
                lines.remove(i + 3);
                lines.remove(i + 2);
                lines.remove(i + 1);
                lines.remove(i);
            }
        }
        // Writes new file with updated price for the selected symbol
        writeIntoFile(stockQuote);
    }

    /**
     * This method is used to find related data based on symbol. It makes used of readFileAndStoreInList method.
     *
     * @param symbol This is a stock symbol to be found.
     * @return StockQuote This returns stock quote or null if it is not found.
     * @exception Exception on input/output error.
     * */
    public StockQuote findSymbol(String symbol) throws Exception{
        stockQuote = new StockQuote();
        readFileAndStoreInList();

        for (int i = 0; i < lines.size(); i++){
            if (lines.get(i).equalsIgnoreCase("\"Symbol\": " + "\"" + symbol + "\",")){
                stockQuote.setSymbol(Extraction.extractValueOf("Symbol",lines.get(i)));
                stockQuote.setShortCompanyName(Extraction.extractValueOf("CompanyName", lines.get(i + 1)));
                stockQuote.setCurrency(Extraction.extractValueOf("Currency", lines.get(i + 2)));
                stockQuote.setExchangeName(Extraction.extractValueOf("Exchange", lines.get(i + 3)));
                stockQuote.setCurrentPrice(Extraction.extractValueOf("Price", lines.get(i + 4)));
                stockQuote.setHigh(Extraction.extractValueOf("High", lines.get(i + 5)));
                stockQuote.setLow(Extraction.extractValueOf("Low", lines.get(i + 6)));
                stockQuote.setOpen(Extraction.extractValueOf("Open", lines.get(i + 7)));
                stockQuote.setPreviousClose(Extraction.extractValueOf("PreviousClose", lines.get(i + 8) + ","));
            }
        }
        lines.clear();

        return stockQuote.getCurrentPrice() == null ? null : stockQuote;
    }

    /**
     * This method is used to write stock quote into a file in json format.
     *
     * @param stockQuote This is a stock quote to be written into a file.
     * @return Nothing.
     * @exception Exception on input/output error.
     * */
    private void writeIntoFile(StockQuote stockQuote) throws IOException {
        this.lines.add("\"Symbol\": " + stockQuote.getSymbol() + ",");
        this.lines.add("\"CompanyName\": " + stockQuote.getShortCompanyName() + ",");
        this.lines.add("\"Currency\": " + stockQuote.getCurrency() + ",");
        this.lines.add("\"Exchange\": " + stockQuote.getExchangeName() + ",");
        this.lines.add("\"Price\": " + Double.parseDouble(stockQuote.getCurrentPrice()) + ",");
        this.lines.add("\"High\": " + Double.parseDouble(stockQuote.getHigh()) + ",");
        this.lines.add("\"Low\": " + Double.parseDouble(stockQuote.getLow()) + ",");
        this.lines.add("\"Open\": " + Double.parseDouble(stockQuote.getOpen()) + ",");
        this.lines.add("\"PreviousClose\": " + Double.parseDouble(stockQuote.getPreviousClose()) + "");

        // save the json file from the array lines
        try {
            bw = new BufferedWriter(new FileWriter(file));
            bw.write("[\n");
            for (int i = 0; i < lines.size(); i += 9) {
                if (i + 9 == lines.size()) {
                    bw.write("\t{" +
                            "\n\t\t" + lines.get(i) +
                            "\n\t\t" + lines.get(i + 1) +
                            "\n\t\t" + lines.get(i + 2) +
                            "\n\t\t" + lines.get(i + 3) +
                            "\n\t\t" + lines.get(i + 4) +
                            "\n\t\t" + lines.get(i + 5) +
                            "\n\t\t" + lines.get(i + 6) +
                            "\n\t\t" + lines.get(i + 7) +
                            "\n\t\t" + lines.get(i + 8) +
                            "\n\t}\n");
                } else {
                    bw.write("\t{" +
                            "\n\t\t" + lines.get(i) +
                            "\n\t\t" + lines.get(i + 1) +
                            "\n\t\t" + lines.get(i + 2) +
                            "\n\t\t" + lines.get(i + 3) +
                            "\n\t\t" + lines.get(i + 4) +
                            "\n\t\t" + lines.get(i + 5) +
                            "\n\t\t" + lines.get(i + 6) +
                            "\n\t\t" + lines.get(i + 7) +
                            "\n\t\t" + lines.get(i + 8) +
                            "\n\t},\n");
                }
            }
            bw.write("]");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            bw.flush();
            bw.close();
            lines.clear();
        }
    }

    /**
     * This method is used to read a file and store it into a list.
     *
     * @return Nothing.
     * @exception Exception on input/output error.
     * */
    private void readFileAndStoreInList() throws IOException {
        try {
            br = new BufferedReader(new FileReader(file));
            while ((line = br.readLine()) != null) {
                if (
                        line.startsWith("\t\t\"Symbol") ||
                        line.startsWith("\t\t\"Price") ||
                        line.startsWith("\t\t\"CompanyName") ||
                        line.startsWith("\t\t\"Currency") ||
                        line.startsWith("\t\t\"Exchange") ||
                        line.startsWith("\t\t\"High") ||
                        line.startsWith("\t\t\"Low") ||
                        line.startsWith("\t\t\"Open") ||
                        line.startsWith("\t\t\"PreviousClose")
                ) {
                    lines.add(line.trim());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            br.close();
        }
    }

}
