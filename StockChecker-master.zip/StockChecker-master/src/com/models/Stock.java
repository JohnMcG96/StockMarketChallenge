package com.models;

/**
 * <h1>Stock</h1>
 * <p>This class is to store data about a stock. It also contains setters and getters for all private fields</p>
 *
 * @author Tomas Kaiser
 * @version 1.0
 * @since 04-11-2020
 */

public class Stock {
    private String symbol;
    private String shortCompanyName;
    private String currency;
    private String exchangeName;

    public String getSymbol() {
        return symbol;
    }

    public String getShortCompanyName() {
        return shortCompanyName;
    }

    public String getCurrency() {
        return currency;
    }

    public String getExchangeName() {
        return exchangeName;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public void setShortCompanyName(String shortCompanyName) {
        this.shortCompanyName = shortCompanyName;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public void setExchangeName(String exchangeName) {
        this.exchangeName = exchangeName;
    }
}
