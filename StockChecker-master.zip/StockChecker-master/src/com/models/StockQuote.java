package com.models;

/**
 * <h1>StockQuote</h1>
 * <p>This class inherits from Stock and contains additional information.
 * Setters and getters are in place for all private fields</p>
 *
 * @author Tomas Kaiser
 * @version 1.0
 * @since 04-11-2020
 */

public class StockQuote extends Stock {
    private String currentPrice;
    private String low;
    private String high;
    private String open;
    private String previousClose;

    public String getCurrentPrice() {
        return currentPrice;
    }

    public String getLow() {
        return low;
    }

    public String getHigh() {
        return high;
    }

    public String getOpen() {
        return open;
    }

    public String getPreviousClose() {
        return previousClose;
    }

    public void setCurrentPrice(String currentPrice) {
        this.currentPrice = currentPrice;
    }

    public void setLow(String low) {
        this.low = low;
    }

    public void setHigh(String high) {
        this.high = high;
    }

    public void setOpen(String open) {
        this.open = open;
    }

    public void setPreviousClose(String previousClose) {
        this.previousClose = previousClose;
    }
}
