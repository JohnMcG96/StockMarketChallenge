package com.tests;

import com.resources.PropertiesFile;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PropertiesFileTest {

    @Test
    @DisplayName("Checking API endpoint")
    void getAPIEndpoint() throws Exception {
        assertEquals(
                "https://yahoo-finance15.p.rapidapi.com/api/yahoo/qu/quote/",
                PropertiesFile.getPropertiesFile().getProperty("APIEndpoint"),
                "Should return API endpoint");
    }

    @Test
    @DisplayName("Checking API Key")
    void getAPIKey() throws Exception {
        assertEquals(
            "962a61d8efmshb349f0ff3c5c39ap15559fjsn0af709dd5967",
                PropertiesFile.getPropertiesFile().getProperty("APIKey"),
                "Should return api key");
    }
}