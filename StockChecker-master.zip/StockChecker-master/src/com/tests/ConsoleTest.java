package com.tests;

import com.utils.Console;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

class ConsoleTest {
    private String regexForSymbol;
    private String regexForYN;

    @BeforeEach
    void init() throws Exception {
        regexForSymbol = "^[a-zA-Z]{3}?[., , -][a-zA-Z]{1,2}$|^[a-zA-Z]{1,6}$";
        regexForYN = "^[y | Y | n | N]{1}$";
    }

    @Test
    void isInputValid(){
        assertAll(
                () -> assertEquals(true, Console.isInputValid("aaa", regexForSymbol)),
                () -> assertEquals(false, Console.isInputValid("aa a", regexForSymbol)),
                () -> assertEquals(true, Console.isInputValid("a", regexForSymbol)),
                () -> assertEquals(false, Console.isInputValid("@", regexForSymbol)),
                () -> assertEquals(false, Console.isInputValid("1", regexForSymbol)),
                () -> assertEquals(true, Console.isInputValid("vod.l", regexForSymbol)),
                () -> assertEquals(true, Console.isInputValid("Y", regexForYN)),
                () -> assertEquals(true, Console.isInputValid("y", regexForYN)),
                () -> assertEquals(true, Console.isInputValid("N", regexForYN)),
                () -> assertEquals(true, Console.isInputValid("n", regexForYN)),
                () -> assertEquals(false, Console.isInputValid("no", regexForYN)),
                () -> assertEquals(false, Console.isInputValid("b", regexForYN))
        );
    }
}