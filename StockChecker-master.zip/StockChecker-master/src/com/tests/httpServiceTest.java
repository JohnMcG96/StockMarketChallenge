package com.tests;

import com.services.HttpService;
import com.resources.PropertiesFile;
import com.models.StockQuote;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class httpServiceTest {

    HttpService httpService;

    @BeforeEach
    void init() throws Exception {
        httpService = new HttpService(PropertiesFile.getPropertiesFile(), new StockQuote());
    }

    @Test
    void getApple() {
        assertEquals("\"AAPL\"", httpService.get("aapl").getSymbol(), "Should return a correct uppercase symbol");
        assertEquals("\"NasdaqGS\"", httpService.get("aapl").getExchangeName(), "Should return a correct exchange name");
    }

    @Test
    void getRetheon() {
        assertEquals("\"RTX\"", httpService.get("rtx").getSymbol(), "Should return a correct uppercase symbol");
        assertEquals("\"NYSE\"", httpService.get("rtx").getExchangeName(), "Should return a correct exchange name");
    }
}