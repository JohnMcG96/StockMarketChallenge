package com.tests;

import com.utils.Extraction;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ExtractionTest {

    @Test
    void extractValueOf() {
        assertAll(
                () -> assertEquals("Not Found",
                        Extraction.extractValueOf("symbol",
                        "price: " + 180.80),
                        "Should return Not Found."),
                () -> assertEquals("AAPL",
                        Extraction.extractValueOf("symbol",
                        "\"symbol\": AAPL,"),
                        "Should return AAPL.")
        );
    }
}