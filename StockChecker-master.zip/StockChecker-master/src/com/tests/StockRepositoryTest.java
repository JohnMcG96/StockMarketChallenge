package com.tests;

import com.models.StockQuote;
import com.dao.StockRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StockRepositoryTest {
    StockRepository stockRepository;
    StockQuote stockQuote;

    @BeforeEach
    void init(){
        stockRepository = new StockRepository();
        stockQuote = new StockQuote();
    }

    @Test
    void findSymbol() {
        assertAll(
                () -> assertEquals("\"AAPL\"", stockRepository.findSymbol("aapl").getSymbol(), "Should find the symbol of apple."),
                () -> assertEquals(null, stockRepository.findSymbol("alal"), "Should return null as 'alal' symbol does not exists")
        );
    }
}