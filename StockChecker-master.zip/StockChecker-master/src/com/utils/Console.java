package com.utils;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <h1>Console</h1>
 * <p>This class is used to read an input from the command line.</p>
 *
 * @author Tomas Kaiser
 * @version 1.0
 * @since 04-11-2020
 * */

public class Console {
    private static Scanner sc = new Scanner(System.in);

    /**
     * This method reads & validate an input from the command line.
     *
     * @param prompt This contains a sentence which is displayed in command line.
     * @param regex
     * @return String This returns a validated input from the command line.
     * */
    public static String readText(String prompt, String regex) {
        String inputText;
        while(true){
            System.out.print(prompt);
            inputText = sc.nextLine().trim().toUpperCase();
            if (!isInputValid(inputText, regex)){
                System.out.println("Invalid input");
            } else {
                break;
            }
        }

        return inputText;
    }

    /**
     * This method is used to validate an input from the command line. The input text cannot be shorter than min number,
     * greater than max number and cannot contain inner spaces.
     *
     * @param inputText This is an input from the command line.
     * @param regex This defines a pattern that we are looking for.
     * @return boolean This returns true or false.
     * */
    public static boolean isInputValid(String inputText, String regex){
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(inputText);
        return matcher.find();
    }
}
