package com.utils;

/**
 * <h1>Extraction</h1>
 * <p>This class is used to extract value from a text</p>
 *
 * @author Tomas Kaiser
 * @version 1.0
 * @since 04-11-2020
 * */

public class Extraction {

    /**
     * This method is used to get a value from a text.
     *
     * @param value This value represents a word we want to extract from the text.
     * @param text This is a text where we want to extract the word from.
     *             The text is supposed to be in key-value format.
     * @return String This returns a value.
     * */

    public static String extractValueOf(String value, String text) {
        short index = (short)text.indexOf(value);
        StringBuffer returnValue = new StringBuffer();
        if(index == -1){
            return "Not Found";
        } else {
            // 3 to capture the value from the response body
            int start = index + value.length() + 3;
            while(true){
                if (text.charAt(start) != ','){
                    returnValue.append(text.charAt(start));
                    start++;
                } else {
                    return returnValue.toString();
                }
            }
        }
    }
}
