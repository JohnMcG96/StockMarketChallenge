package com.services;

import com.models.StockQuote;
import com.utils.Extraction;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Properties;

/**
 * <h1>HttpService</h1>
 * <p>This class is to used call API to retrieve data about particular stock.</p>
 *
 * @author Tomas Kaiser
 * @version 1.0
 * @since 04-11-2021
 * */

public class HttpService {
    private Properties properties;
    private StockQuote stockQuote;

    public HttpService(Properties properties, StockQuote stockQuote) {
        this.properties = properties;
        this.stockQuote = stockQuote;
    }

    /**
     * This method is used to call API to get data about stock.
     *
     * @param stockSymbol This is a name of the stock we want to get data such as AAPL.
     * @return StockQuote This returns the stock quote information we asked for.
     * */
    public StockQuote get(String stockSymbol) {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(properties.getProperty("APIEndpoint") + stockSymbol))
                .header("x-rapidapi-host", "yahoo-finance15.p.rapidapi.com")
                .header("x-rapidapi-key", properties.getProperty("APIKey"))
                .build();
        client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(HttpResponse::body)
                .thenApply(this::parseStockQuote)
                .join();

        return getStockQuote();
    }

    /**
     * This method take particular data from response body which we want to store into stock quote.
     * It makes use of static method extractValueOf.
     *
     * @param responseBody This a response body got it from API.
     * @return null
     * */
    private String parseStockQuote(String responseBody){
        String symbol = Extraction.extractValueOf("symbol", responseBody);
        stockQuote.setSymbol(symbol);

        String shortCompanyName = Extraction.extractValueOf("shortName", responseBody);
        stockQuote.setShortCompanyName(shortCompanyName);

        String currency = Extraction.extractValueOf("currency", responseBody);
        stockQuote.setCurrency(currency);

        String exchangeName = Extraction.extractValueOf("fullExchangeName", responseBody);
        stockQuote.setExchangeName(exchangeName);

        String currentPrice = Extraction.extractValueOf("ask", responseBody);
        stockQuote.setCurrentPrice(currentPrice);

        String low = Extraction.extractValueOf("regularMarketDayLow", responseBody);
        stockQuote.setLow(low);

        String high = Extraction.extractValueOf("regularMarketDayHigh", responseBody);
        stockQuote.setHigh(high);

        String open = Extraction.extractValueOf("regularMarketOpen", responseBody);
        stockQuote.setOpen(open);

        String previousClose = Extraction.extractValueOf("regularMarketPreviousClose", responseBody);
        stockQuote.setPreviousClose(previousClose);

        return null;
    }

    /**
     * This method is used to return a StockQuote.
     *
     * @return StockQuote
     * */
    private StockQuote getStockQuote(){
        return stockQuote;
    }

}
