package com.services;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * <h1>CreateFile</h1>
 * <p>This class is used to create a file in temp directory.</p>
 * */
public class CreateFile {

    public static void createJSONFile(String name) {
        try {
            // Create a dir if does not exist
            Path path = Paths.get("temp");
            if(!Files.exists(path)){
                Files.createDirectories(path);
            }

            // Create a file if does not exist
            File file = new File("temp/" + name + ".json");
            file.createNewFile();

        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
