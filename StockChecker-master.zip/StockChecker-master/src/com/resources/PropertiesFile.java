package com.resources;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * <h1>PropertiesFile</h1>
 * <p>This class is used to load .properties file.</p>
 * */

public class PropertiesFile {
    /**
     * This method is used to load data from config.properties.
     *
     * @exception IOException on input error and file not found error.
     * @return Properties This returns all data from config.properties.
     * */
    public static Properties getPropertiesFile() throws Exception {
        InputStream is = PropertiesFile.class.getResourceAsStream("/resources/config.properties");
        Properties prop = new Properties();
        prop.load(is);

        return prop;
    }
}
