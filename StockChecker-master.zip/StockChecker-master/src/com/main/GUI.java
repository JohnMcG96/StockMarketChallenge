package com.main;

import com.dao.StockRepository;
import com.models.StockQuote;
import com.services.HttpService;
import com.utils.Console;

/**
 * <h1>Graphical User Interface in Command Line</h1>
 * <p>This class is used to display information in command line interface.</p>
 *
 * */

public class GUI {
    private HttpService httpService;
    private String stockSymbol;
    private StockRepository stockRepository;
    private StockQuote stockQuote;

    public GUI (HttpService httpService, String stockSymbol, StockRepository stockRepository) throws Exception {
        this.httpService = httpService;
        this.stockSymbol = stockSymbol;
        this.stockRepository = stockRepository;
        this.stockQuote = getStockQuote();
    }

    /**
     * This method is used to run a GUI in command line interface.
     *
     * @exception Exception on input/output error.
     * */
    public void display() throws Exception {
        if (stockQuote == null){
            // Calling HttpService to get a current price
            stockQuote = httpService.get(stockSymbol);
            System.out.println(stockQuote.getCurrentPrice());
            if (stockQuote.getCurrentPrice().equalsIgnoreCase("Not Found") ||
                    stockQuote.getCurrentPrice().equalsIgnoreCase("null")){
                System.out.println("Such a symbol does not exist, try again.");
            } else {
                displayStockDetails(stockQuote);
                // StockRepository symbol and price into json file
                stockRepository.save(stockQuote);
            }
            return;
        }

        displayStockDetails(stockQuote);
        String refresh = Console.readText("Do you want to refresh? Y/N: ", "^[y | n | Y | N]{1}$");

        if (refresh.equalsIgnoreCase("Y")){
            // Calling HttpService
            stockQuote = httpService.get(stockSymbol);
            displayStockDetails(stockQuote);

            // Update the price into json file
            stockRepository.update(stockQuote);
        }
    }

    /**
     * This method prints out a detail of the stock quote.
     *
     * @param stockQuote This is a stock quote to be printed out.
     * */
    private void displayStockDetails(StockQuote stockQuote){
        System.out.println();
        System.out.println("Stock Details of " + stockQuote.getShortCompanyName());
        System.out.println("------------------------------");
        System.out.println("Name: " + stockQuote.getShortCompanyName());
        System.out.println("Symbol: " + stockQuote.getSymbol());
        System.out.println("Exchange: " + stockQuote.getExchangeName());
        System.out.println("Current price: " + stockQuote.getCurrentPrice());
        System.out.println("Currency: " + stockQuote.getCurrency());
        System.out.println("Open: " + stockQuote.getOpen());
        System.out.println("High: " + stockQuote.getHigh());
        System.out.println("Low: " + stockQuote.getLow());
        System.out.println("Previous Close: " + stockQuote.getPreviousClose());
        System.out.println();
    }

    /**
     * This method makes used of findSymbol method to find a symbol stored in a file.
     *
     * @exception Exception on input/output error.
     * */
    private StockQuote getStockQuote() throws Exception {
        return stockRepository.findSymbol(stockSymbol);
    }
}
