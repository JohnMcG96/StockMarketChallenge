package com.main;

import com.dao.StockRepository;
import com.models.StockQuote;
import com.resources.PropertiesFile;
import com.services.HttpService;
import com.utils.Console;

/**
 * <h1>Main!</h1>
 * <p>This class contains a main method to run a command line for retrieving and printing stocks.</p>
 *
 * @author Tomas Kaiser
 * @version 1.0
 * @since 04-11-2020
 * */

public class Main {

    /**
     * This is the main method which makes use of readText & display method.
     * @param args Unused.
     * @return Nothing.
     * @exception Exception on input error.
     * @see Exception
     * */
    public static void main(String[] args) throws Exception {
        // Read a stock symbol from console
        String stockSymbol = Console.readText("Enter a symbol of the stock: ", "^[a-zA-Z]{3}?[., , -][a-zA-Z]{1,2}$|^[a-zA-Z]{1,6}$");

        // Display presentation in console
        GUI gui = new GUI(
                new HttpService(PropertiesFile.getPropertiesFile(), new StockQuote()),
                stockSymbol,
                new StockRepository());
        gui.display();
    }

}
