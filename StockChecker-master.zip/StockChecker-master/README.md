# Stock Checker - Part 1
This is a Java project for getting a stock quote from Yahoo Finance API using command line interface.

All requirements for stage 1 have been met:
- [x] Use only Core Java libraries no third party or utility libraries.
- [x] Writing good java docs for each class/method.
- [x] Unit test using Junit and 80% code coverage
- [x] Git repository for code and Mark down Readme.
- [x] Use appropriate code package to separate different parts of application

## How to run
This can be run on any OS unless JRE is installed.

To run JAR file from command line:

    `java -jar StockChecker/out/artifacts/StockChecker_jar`
    
## Technologies Used
- Java 11 JDK
- JUnit
- Rapid API
- IntelliJ IDEA

## Testing coverage
| Element | Class %   | Method % | Line %       |
| --------| --------- | -------- | -------------|
| com     |86% (13/15)|75% (46/61)|57% (160/277)|

## Folder Structure
```
.
|- out
|- src
|    |- com
|    |   |- dao
|    |   |- main
|    |   |- models
|    |   |- resources
|    |   |- serivces
|    |   |- tests
|    |   |- utils
|    |   
|    |- resources                  
|- temp

```