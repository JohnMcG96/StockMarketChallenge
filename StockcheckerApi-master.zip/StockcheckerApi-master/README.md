# Stock Checker API
This is a Java Spring Boot REST API project for getting a stock quote from Yahoo Finance API.

All requirements for stage 2 have been met:

- [x] Spring Boot application with REST interface.
- [x] Using Maven to structure and build application.
- [x] Run spring boot application from command line (embedded tomcat container)
- [x] Make use of Swagger to expose and API Details
- [x] Use spring and mock to write tests.
- [x] Use embedded SQL Lite Database for storing data into tables
- [x] Use spring Repository class for Data Access services


## How to Run
Download the project from GitHub and open a CLI in the root directory and run:

`java -jar target/StockCheckerApi.jar`

Another approach is to create a Docker container:

`docker build -f Dockerfile -t docker-stock-checker-api .`

Listening on local port 8090

`docker run -p 8090:8080 docker-stock-checker-api`
  
## Usage of Swagger
Once the app is up and running, use 
http://host:port/swagger-ui/ to expose API

## Accepted Stock Symbols
| Symbol | Acceptance |
| ----------- | ----------- |
| A | YES |
| AAPL | YES |
| aapl | YES |
| VOD.L | YES |
| VOD L | YES |
| VOD-L | YES |
| VOD.LN | YES |
| 1 | NO |
| @ | NO |
| AA PL | NO |

## Technologies Used
- Java 11 JDK
- JUnit
- Rapid API
- log4j
- org.json
- Swagger
- SQLite
- H2
- Docker
- IntelliJ IDEA

## Folder Structure
```
.
|- src
|    |- mian
|    |    |- java
|    |    |    |- com.tomas.StockChechkerApi
|    |    |                |- controllers
|    |    |                |- dao
|    |    |                |- exceptions
|    |    |                |- modes
|    |    |                |- resources
|    |    |                |- services
|    |    |                |- utils
|    |    |- resources
|    |    
|    |- test
|        |- java
|            |- com.tomas.StockChechkerApi
|                        |- controllers
|                        |- dao
|                        |- Services
|                        |- Utils
|                        
|- target
|- Dockerfile
|- pom.xml
|- README.md
|- stockQuote.db


```

## Testing coverage
| Element | Class %  | Method %  | Line %       |
| --------| ---------| --------- | -------------|
| com     |90% (9/10)|40% (22/54)|41% (66/160)  |
