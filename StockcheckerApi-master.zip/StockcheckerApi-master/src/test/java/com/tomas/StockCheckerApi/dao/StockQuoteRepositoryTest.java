package com.tomas.StockCheckerApi.dao;

import com.tomas.StockCheckerApi.models.StockQuote;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@RunWith(SpringRunner.class)
@DataJpaTest
class StockQuoteRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private StockQuoteRepository stockQuoteRepository;

    @Test
    public void whenFindBySymbol_thenReturnStockQuote(){
        // Given
        StockQuote stockQuote = new StockQuote();
        stockQuote.setSymbol("AAPL");
        stockQuote.setCurrency("USD");
        entityManager.persist(stockQuote);
        entityManager.flush();

        // When
        StockQuote found = stockQuoteRepository.findById("AAPL").get();

        // Then
        assertThat(found.getSymbol()).isEqualTo(stockQuote.getSymbol());
        assertThat(found.getCurrency()).isEqualTo(stockQuote.getCurrency());

    }
}