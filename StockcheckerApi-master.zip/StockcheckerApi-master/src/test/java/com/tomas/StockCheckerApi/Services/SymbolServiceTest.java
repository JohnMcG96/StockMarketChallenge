package com.tomas.StockCheckerApi.Services;

import com.tomas.StockCheckerApi.dao.StockQuoteRepository;
import com.tomas.StockCheckerApi.models.StockQuote;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@RunWith(SpringRunner.class)
class SymbolServiceTest {

    @InjectMocks
    private SymbolService symbolService;

    @Mock
    private StockQuoteRepository stockQuoteRepository;

    @Test
    void getStockQuoteFromDB() throws Exception {
        StockQuote stockQuote = new StockQuote();
        stockQuote.setSymbol("AAPL");
        stockQuote.setCurrency("USD");

        Mockito.when(stockQuoteRepository.findById("AAPL")).thenReturn(Optional.of(stockQuote));

        StockQuote found = symbolService.getStockQuoteFromDB("AAPL");

        assertThat(found.getSymbol()).isEqualTo(stockQuote.getSymbol());
        assertThat(found.getCurrency()).isEqualTo(stockQuote.getCurrency());
    }
}