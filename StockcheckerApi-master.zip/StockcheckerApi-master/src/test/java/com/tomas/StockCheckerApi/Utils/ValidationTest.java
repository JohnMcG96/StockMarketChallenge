package com.tomas.StockCheckerApi.Utils;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ValidationTest {

    @Test
    @DisplayName("To validate provided symbol.")
    void isSymbolValid() {
        assertAll(
                () -> assertEquals(true, Validation.isSymbolValid("aapl"), "Symbol: aapl"),
                () -> assertEquals(true, Validation.isSymbolValid("AAPL"),"Symbol: AAPL"),
                () -> assertEquals(true, Validation.isSymbolValid("B"), "Symbol: B"),
                () -> assertEquals(true, Validation.isSymbolValid("b"), "Symbol: b"),
                () -> assertEquals(true, Validation.isSymbolValid("BA"), "Symbol: BA"),
                () -> assertEquals(true, Validation.isSymbolValid("VOD uq"), "Symbol: VOD uq"),
                () -> assertEquals(true, Validation.isSymbolValid("VOD L"), "Symbol: VOD L"),
                () -> assertEquals(true, Validation.isSymbolValid("VOD LN"), "Symbol: VOD LN"),
                () -> assertEquals(true, Validation.isSymbolValid("VOD-L"), "Symbol: VOD-L"),
                () -> assertEquals(true, Validation.isSymbolValid("VOD-LN"), "Symbol: VOD-LN"),
                () -> assertEquals(true, Validation.isSymbolValid("VOD.L"), "Symbol: VOD.L"),
                () -> assertEquals(true, Validation.isSymbolValid("VOD.LN"), "Symbol: VOD.LN"),
                () -> assertEquals(false, Validation.isSymbolValid("aapllls"), "massage: aapllls"),
                () -> assertEquals(false, Validation.isSymbolValid("V O"), "Symbol: V O"),
                () -> assertEquals(false, Validation.isSymbolValid("V.O"), "Symbol: V.O"),
                () -> assertEquals(false, Validation.isSymbolValid("VOD  O"), "Symbol: VOD  O"),
                () -> assertEquals(false, Validation.isSymbolValid("VOD..O"), "Symbol: VOD..O"),
                () -> assertEquals(false, Validation.isSymbolValid("1"), "Symbol: 1"),
                () -> assertEquals(false, Validation.isSymbolValid("V1N"), "Symbol: V1N"),
                () -> assertEquals(false, Validation.isSymbolValid("V*N"), "Symbol: V1N"),
                () -> assertEquals(false, Validation.isSymbolValid("V@N"), "Symbol: V1N"),
                () -> assertEquals(false, Validation.isSymbolValid("aa pl"), "Symbol: aa pl")
        );
    }
}