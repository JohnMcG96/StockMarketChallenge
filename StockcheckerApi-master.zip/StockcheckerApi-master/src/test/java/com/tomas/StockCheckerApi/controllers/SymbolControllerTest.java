package com.tomas.StockCheckerApi.controllers;


import com.tomas.StockCheckerApi.Services.SymbolService;
import com.tomas.StockCheckerApi.exceptions.SymbolNotFoundException;
import com.tomas.StockCheckerApi.models.StockQuote;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@WebMvcTest(SymbolController.class)
public class SymbolControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SymbolService symbolService;

    private StockQuote stockQuote;

    @Before
    public void setUp(){
        stockQuote = new StockQuote();
        stockQuote.setSymbol("aapl");
        stockQuote.setCurrentPrice((float)112.19);
    }

    @Test
    @DisplayName("Test to get data from DB")
    public void testGetStockQuoteFromDB() throws Exception {

        when(symbolService.getStockQuoteFromDB("aapl")).thenReturn(stockQuote);

        mockMvc.perform(get("/stockapp/stock/aapl")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.symbol", Matchers.is(stockQuote.getSymbol())))
                .andExpect(jsonPath("$.currentPrice", Matchers.is(stockQuote.getCurrentPrice()), Float.class));

        verify(symbolService).getStockQuoteFromDB("aapl");
    }

    @Test
    @DisplayName("Test to handle SymbolNotFoundException when it is not found in DB")
    public void testSymbolNotFoundException() throws Exception {
        when(symbolService.getStockQuoteFromDB("aapl")).thenThrow(new SymbolNotFoundException());

        mockMvc.perform(get("/stockapp/stock/aapl"))
                .andExpect(status().isNotFound());

        verify(symbolService).getStockQuoteFromDB("aapl");
    }

    @Test
    @DisplayName("Test to get data from API")
    public void testGetStockQuoteFromAPI() throws Exception {
        when(symbolService.getStockQuoteFromApi("aapl")).thenReturn(stockQuote);

        mockMvc.perform(post("/stockapp/stock/aapl")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

        verify(symbolService).getStockQuoteFromApi("aapl");
    }

}