package com.tomas.StockCheckerApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockCheckerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
