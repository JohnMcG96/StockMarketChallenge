package com.tomas.StockCheckerApi.controllers;

import com.tomas.StockCheckerApi.Services.SymbolService;
import com.tomas.StockCheckerApi.exceptions.SymbolNotFoundException;
import com.tomas.StockCheckerApi.models.StockQuote;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

/**
 * <h1>Controller</h1>
 * <p>This class is used for receiving http verbs and matching endpoints.</p>
 *
 * @author Tomas Kaiser
 * @version 1.0
 * @since 10-11-2020
 **/

@RestController
@RequestMapping("/stockapp/stock")
public class SymbolController {

    @Autowired
    SymbolService symbolService;

    @GetMapping("/{symbol}")
    public StockQuote getStockQuoteFromDB(@PathVariable String symbol){
        try {
            return symbolService.getStockQuoteFromDB(symbol);
        } catch (SymbolNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
        }
    }

    @PostMapping("/{symbol}")
    public StockQuote getStockQuoteFromApi(@PathVariable String symbol) {
        try {
            return symbolService.getStockQuoteFromApi(symbol);
        } catch (SymbolNotFoundException e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e);
        }
    }
}
