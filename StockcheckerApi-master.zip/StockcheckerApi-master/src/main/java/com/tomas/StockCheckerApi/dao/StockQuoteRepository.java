package com.tomas.StockCheckerApi.dao;

import com.tomas.StockCheckerApi.models.StockQuote;
import org.springframework.data.repository.CrudRepository;

/**
 * <h1>StockQouteRepository</h1>
 * <p>This interface is used for manipulating with DB using CRUD.</p>
 *
 * @author Tomas Kaiser
 * @version 1.0
 * @since 10-11-2020
 **/
public interface StockQuoteRepository extends CrudRepository<StockQuote, String> {
}
