package com.tomas.StockCheckerApi.Services;

import com.tomas.StockCheckerApi.Utils.Validation;
import com.tomas.StockCheckerApi.dao.StockQuoteRepository;
import com.tomas.StockCheckerApi.exceptions.SymbolNotFoundException;
import com.tomas.StockCheckerApi.models.StockQuote;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.logging.Logger;

/**
 * <h1>SymbolService</h1>
 * <p>This class is used for calling external API or getting/saving data from/to DB</p>
 *
 * @author Tomas Kaiser
 * @version 1.0
 * @since 10-11-2020
 **/

@Service
public class SymbolService {
    private static final Logger log = Logger.getLogger(SymbolService.class.getName());
    private StockQuote stockQuote;

    @Autowired
    HttpService httpService;

    @Autowired
    StockQuoteRepository stockQuoteRepository;


    /**
     * This method is used to get stock quote from DB.
     *
     * @param symbol This is a symbol we are looking for.
     * @retun StockQuote.
     * @exception SymbolNotFoundException This checked exception is thrown in case it is not found in DB.
     * */
    public StockQuote getStockQuoteFromDB(String symbol) throws SymbolNotFoundException {
        if (!Validation.isSymbolValid(symbol)){
            throw new SymbolNotFoundException("Symbol does not exist.");
        }

        // If symbol exists in DB, retrieve data from DB otherwise throw SymbolNotFoundException.
        log.info("action=getStockQuoteFromDB, receive=symbol, symbol=" + symbol);
        if (stockQuoteRepository.findById(symbol.toUpperCase()).isPresent()) {
            return stockQuoteRepository.findById(symbol.toUpperCase()).get();
        }

        throw new SymbolNotFoundException("Symbol not found in DB.");
    }

    /**
     * This method is used to call external API to get data, save it in DB and return stock quote.
     *
     * @param symbol This is a symbol we are looking for.
     * @retun StockQuote.
     * @exception SymbolNotFoundException This checked exception is thrown in case it is not found in DB.
     * */
    public StockQuote getStockQuoteFromApi(String symbol) throws SymbolNotFoundException {
        if (!Validation.isSymbolValid(symbol)){
            throw new SymbolNotFoundException("Provided symbol " + symbol + " does not exist.");
        }

        // Get a stock quote from API
        log.info("action=getStockQuoteFromApi, receive=symbol, symbol=" + symbol);
        stockQuote = httpService.get(symbol);

        // If not exist in DB, add to DB otherwise the DB will be updated.
        log.info("action=updateOrAddToDB");
        stockQuoteRepository.save(stockQuote);
        return stockQuote;
    }
}
