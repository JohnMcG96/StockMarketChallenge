package com.tomas.StockCheckerApi.exceptions;

/**
 * <h1>SymbolNotFoundException</h1>
 * <p>This class is customized checked exception</p>
 *
 * @author Tomas Kaiser
 * @version 1.0
 * @since 10-11-2020
 **/
public class SymbolNotFoundException extends Exception {
    public SymbolNotFoundException() {
        super("Symbol not found!");
    }

    public SymbolNotFoundException(String message) {
        super(message);
    }
}
