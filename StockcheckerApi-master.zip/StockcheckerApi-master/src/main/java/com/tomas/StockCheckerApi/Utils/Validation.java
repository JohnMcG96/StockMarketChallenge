package com.tomas.StockCheckerApi.Utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <h1>Validation</h1>
 * <p>This class is used to validate a symbol</p>
 *
 * @author Tomas Kaiser
 * @version 1.0
 * @since 12-11-2020
 * */
public class Validation {

    /**
     * This static method validate a symbol.
     *
     * @param symbol This contains a String symbol.
     * @return boolean This returns true or false.
     * */
    public static boolean isSymbolValid(String symbol) {
        Pattern pattern = Pattern.compile("^[a-zA-Z]{3}?[., , -][a-zA-Z]{1,2}$|^[a-zA-Z]{1,6}$");
        Matcher matcher = pattern.matcher(symbol);

        return matcher.find();
    }
}