package com.tomas.StockCheckerApi.Services;

import com.tomas.StockCheckerApi.exceptions.SymbolNotFoundException;
import com.tomas.StockCheckerApi.resources.PropertiesFile;
import com.tomas.StockCheckerApi.models.StockQuote;
import org.json.JSONArray;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.ExecutionException;

/**
 * <h1>HttpService</h1>
 * <p>This class is to used call API to retrieve data about particular stock.</p>
 *
 * @author Tomas Kaiser
 * @version 1.0
 * @since 04-11-2021
 * */

@Service
public class HttpService {
    private StockQuote stockQuote;

    /**
     * This method is used to call API to get data about stock.
     *
     * @param stockSymbol This is a name of the stock we want to get data such as AAPL.
     * @return StockQuote This returns the stock quote information we asked for.
     * */
    public StockQuote get(String stockSymbol) throws SymbolNotFoundException {
        stockQuote = new StockQuote();
        HttpClient client = HttpClient.newHttpClient();

        // Create a request
        HttpRequest request = null;
        try {
            request = HttpRequest.newBuilder()
                    .uri(URI.create(PropertiesFile.getPropertiesFile().getProperty("APIEndpoint") + stockSymbol))
                    .header("x-rapidapi-host", "yahoo-finance15.p.rapidapi.com")
                    .header("x-rapidapi-key", PropertiesFile.getPropertiesFile().getProperty("APIKey") )
                    .build();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Handle a response and parsing the response using JSONObject
        try {
            String responseBody = client.sendAsync(request, HttpResponse.BodyHandlers.ofString()).get().body();
            parseToJsonObject(responseBody);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

        return stockQuote;
    }

    /**
     * This method takes json response in string and parse into object using org.json
     *
     * @param responseBody This a response body received it from API.
     * @return null
     * */
    private void parseToJsonObject(String responseBody) throws SymbolNotFoundException {
        JSONArray arr = new JSONArray(responseBody);
        if (arr.isEmpty())
            throw new SymbolNotFoundException();

        for (int i = 0; i < arr.length(); i++) {
            String symbol = arr.getJSONObject(i).getString("symbol");
            stockQuote.setSymbol(symbol);

            String shortCompanyName = arr.getJSONObject(i).getString("shortName");
            stockQuote.setShortCompanyName(shortCompanyName);

            String currency = arr.getJSONObject(i).getString("currency");
            stockQuote.setCurrency(currency);

            String exchangeName = arr.getJSONObject(i).getString("fullExchangeName");
            stockQuote.setExchangeName(exchangeName);

            float currentPrice = arr.getJSONObject(i).getFloat("ask");
            stockQuote.setCurrentPrice(currentPrice);

            float low = arr.getJSONObject(i).getFloat("regularMarketDayLow");
            stockQuote.setLow(low);

            float high = arr.getJSONObject(i).getFloat("regularMarketDayHigh");
            stockQuote.setHigh(high);

            float open = arr.getJSONObject(i).getFloat("regularMarketOpen");
            stockQuote.setOpen(open);

            float previousClose = arr.getJSONObject(i).getFloat("regularMarketPreviousClose");
            stockQuote.setPreviousClose(previousClose);
        }
    }
}
