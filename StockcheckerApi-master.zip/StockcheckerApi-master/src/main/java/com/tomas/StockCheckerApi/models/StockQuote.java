package com.tomas.StockCheckerApi.models;

import javax.persistence.Entity;

/**
 * <h1>StockQuote</h1>
 * <p>This class inherits from Stock and contains additional information.
 * Setters and getters are in place for all private fields</p>
 *
 * @author Tomas Kaiser
 * @version 1.0
 * @since 04-11-2020
 */
@Entity
public class StockQuote extends Stock {
    private float currentPrice;
    private float low;
    private float high;
    private float open;
    private float previousClose;

    public float getCurrentPrice() {
        return currentPrice;
    }

    public float getLow() {
        return low;
    }

    public float getHigh() {
        return high;
    }

    public float getOpen() {
        return open;
    }

    public float getPreviousClose() {
        return previousClose;
    }

    public void setCurrentPrice(float currentPrice) {
        this.currentPrice = currentPrice;
    }

    public void setLow(float low) {
        this.low = low;
    }

    public void setHigh(float high) {
        this.high = high;
    }

    public void setOpen(float open) {
        this.open = open;
    }

    public void setPreviousClose(float previousClose) {
        this.previousClose = previousClose;
    }
}
